@extends('frontend.master')

@section('title','Home')

@section('style')
    
@endsection

@section('content')

@endsection

@section('script')
    
@endsection