@extends('admin.layouts.master')
@section('title','Admin - Dashboard')

@section('content')

@endsection